<?require "../setup/need.php";

if($_POST[acao]=='ok'){
	mysql_query("UPDATE {$DB_PRENOM}_chat SET status = 'ok' WHERE id = '$_POST[i]' AND usuario = '$_POST[s]'");
}elseif($_POST[acao]=='andamento'){
	mysql_query("UPDATE {$DB_PRENOM}_chat SET status = 'andamento' WHERE id = '$_POST[i]' AND usuario = '$_POST[s]'");
}
?>