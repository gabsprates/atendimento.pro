<fieldset>
	<legend>Fa�a seu login:</legend>
	<form action='./logar/' method='post'>
		<p><span>E-mail:</span><input name='email' /></p>
		<p><span>Senha:</span><input name='senha' type='password' /></p>
		<p><input type='submit' value='entrar >' /></p>
	</form>
</fieldset>
